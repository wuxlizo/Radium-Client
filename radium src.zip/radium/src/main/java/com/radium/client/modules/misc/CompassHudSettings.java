package com.radium.client.modules.misc;
// radium client

import com.radium.client.gui.settings.BooleanSetting;

public class CompassHudSettings {
    public final BooleanSetting editHUD = new BooleanSetting("Edit Compass HUD", false);
}

