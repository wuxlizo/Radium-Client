package com.radium.client.mixins;
// radium client

import net.minecraft.client.network.ClientPlayerEntity;
import org.spongepowered.asm.mixin.Mixin;


@Mixin(ClientPlayerEntity.class)
public class ClientPlayerEntityMixin {


}
