package com.radium.client.modules.misc;

import com.radium.client.modules.Module;

public class ChatUtils extends Module {
    public ChatUtils() {
        super("ChatUtils", "Extends chat history and persists it across servers.", Category.MISC);
    }
}
