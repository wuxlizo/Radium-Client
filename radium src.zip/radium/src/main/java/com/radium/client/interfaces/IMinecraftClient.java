package com.radium.client.interfaces;
// radium client

public interface IMinecraftClient {
    void setItemUseCooldown(int cooldown);
}
