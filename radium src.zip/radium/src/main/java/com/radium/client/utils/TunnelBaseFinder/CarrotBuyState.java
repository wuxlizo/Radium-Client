package com.radium.client.utils.TunnelBaseFinder;
// radium client

public enum CarrotBuyState {
    NONE, OPENSHOP, WAIT1, CLICKFOOD, WAIT2, CLICKCARROT, WAIT3, CLICKSTACK, WAIT4, DROPITEMS, WAIT5, BUY, WAIT6, CLOSE, WAIT7, RESET
}

