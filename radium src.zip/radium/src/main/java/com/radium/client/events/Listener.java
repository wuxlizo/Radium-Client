package com.radium.client.events;
// radium client

import java.util.EventListener;

public interface Listener extends EventListener {
}

