package com.radium.client.utils.TunnelBaseFinder;
// radium client

public enum ObiBuyState {
    NONE, OPENSHOP, WAIT1, CLICKGEAR, WAIT2, CLICKOBI, WAIT3, CLICKSTACK, WAIT4, DROPITEMS, WAIT5, BUY, WAIT6, CLOSE, WAIT7, RESET
}


