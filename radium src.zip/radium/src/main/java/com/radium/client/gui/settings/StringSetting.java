package com.radium.client.gui.settings;
// radium client

public class StringSetting extends Setting<String> {
    public StringSetting(String name, String defaultValue) {
        super(name, defaultValue);
    }
}
