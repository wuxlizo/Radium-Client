package com.radium.client.utils.TunnelBaseFinder;
// radium client

public enum State {
    NONE, MINING, GOABOVEHAZARD, YRECOVERY, BUYOBI, PEARL, BUYPEARL, AUTOMEND, BUYXP, AUTOEAT, BUYCARROT
}
