package com.radium.client.systems.accounts;
// radium client

public enum AccountType {
    Cracked,
    Microsoft
}


