package com.radium.client.utils.TunnelBaseFinder;
// radium client

public enum MendStage {
    ENSURE,
    ROTATE_DOWN,
    OFFHAND_XP,
    THROW_XP,
    REOFFHAND_TOTEM,
    ROTATE_BACK,
    RESET
}

